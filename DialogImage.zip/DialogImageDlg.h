
// DialogImageDlg.h : header file
//

#pragma once
#include "ImageArrange.h"
using namespace Gdiplus;

// CDialogImageDlg dialog
class CDialogImageDlg : public CDialogEx
{
// Construction
public:
	CDialogImageDlg(CWnd* pParent = nullptr);	// standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOGIMAGE_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;
	CToolBar mWndToolBar;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnFolderOpen();
	afx_msg void OnZoomIn();
	afx_msg void OnZoomOut();
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg void SortAndDisplayTree(CString selectedFolder);
	afx_msg void ArrangeImage(int drawX);
	afx_msg void UpdatedScroll(int& rNewWidth, int& rNewHeight);
	afx_msg void OnTvnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnSizing(UINT fwSide, LPRECT pRect);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMove(int x, int y);
	//USER method
	afx_msg void TreeControlInit(int x, int y, int width, int height);
	afx_msg void LayoutInit(bool isLayoutInit);
	afx_msg void ToolbarInit(int x, int y, int width, int height);
	afx_msg void InfoControlInit(int x, int y, int width, int height);
	
private:
	CScrollBar mHorizontalControl;
	CScrollBar mVerticalControl;
	CTreeCtrl mTreeView;
	CStatic mInfoControl;

	ImageArrange mPacker;
	vector<ThisImage> mPositions;
	ThisImage* pDraggedImage = nullptr;
	CPoint mDragStartPoint;

	int mCurrentWidth = 0;
	int mCurrentHeight = 0;

	int mOffsetX = 0;
	int mOffsetY = 0;

	double mCurrentLenScrollWidth = 0;
	double mCurrentPosScrollWidth = 0;

	double mCurrentLenScrollHeight = 0;
	double mCurrentPosScrollHeight = 0;

	double mOldPosScrollWidth = 1.0;
	double mOldPosScrollHeight = 1.0;

	double mOldLenScrollWidth = 1.0;
	double mOldLenScrollHeight = 1.0;

	int mDrawX = 0;
	int mDrawY = 0;
	int mWidthDraw = 0;
	int mHeightDraw = 0;
	CRect mRect;
	
};
