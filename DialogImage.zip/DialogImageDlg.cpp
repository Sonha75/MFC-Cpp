
// DialogImageDlg.cpp : implementation file
//

#include "pch.h"
#include "framework.h"
#include "DialogImage.h"
#include "DialogImageDlg.h"
#include "afxdialogex.h"

//USER INCLUDE
#include "LayoutInit.h"
#include <afxwin.h>
#include <gdiplus.h>
#include <commdlg.h>
#include <cmath>
#include <vector>
#include <memory>
#include "ImageArrange.h"
#include "Image.h"
#include <fstream>
#include <map>
#ifdef _DEBUG
#define new DEBUG_NEW
#endif

using namespace Gdiplus;

//GLOBAL VARIBALES
bool gNewImage = false;	
bool gIsZoomInWidth = false;
bool gIsZoomInHeight = false;
bool gIsZoomOut = false;
bool gIsPainting = false; //allow onpaint draw , true not allow
bool gTreeClicked = false;
bool gImageDraging = false; //not allow drag image, true allow
double gZoomFactor = 1.0f;
CString gSelectedImage;
map<HTREEITEM, CString> itemDataMap;
static bool gIsLayoutInit = false;


//USER_DEFINED FUNCTION
bool IsPointInImage(const ThisImage& rImage, const CPoint& rPoint, int xPadding, int yPadding);
void FindImageFiles(const CString& dirPath);

// CAboutDlg dialog used for App About

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CDialogImageDlg dialog



CDialogImageDlg::CDialogImageDlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOGIMAGE_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDialogImageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_SCROLLBAR_HORIZONTAL, mHorizontalControl);
	DDX_Control(pDX, IDC_SCROLLBAR_VERTICAL, mVerticalControl);
}

BEGIN_MESSAGE_MAP(CDialogImageDlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_COMMAND(ID_FILE_OPEN, &CDialogImageDlg::OnFolderOpen)
	ON_WM_VSCROLL()
	ON_WM_HSCROLL()
	ON_NOTIFY(TVN_SELCHANGED, IDC_TREE1, &CDialogImageDlg::OnTvnSelchangedTree1)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_COMMAND(ID_BUTTON_IN, &CDialogImageDlg::OnZoomIn)
	ON_COMMAND(ID_BUTTON_OUT, &CDialogImageDlg::OnZoomOut)
	ON_WM_SIZING()
	ON_WM_SIZE()
	ON_WM_MOVE()
END_MESSAGE_MAP()

//BOOL CDialogImageDlg::OnEraseBkgnd(CDC* pDC)
//{
//
//	return TRUE;
//}
// CDialogImageDlg message handlers

BOOL CDialogImageDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();
	LayoutInit(gIsLayoutInit);
	gIsLayoutInit = true;
	/*mVerticalControl.SetScrollRange(0, 100);
	mVerticalControl.SetScrollPos(50);
	mHorizontalControl.SetScrollRange(0, 100);*/

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CDialogImageDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CDialogImageDlg::OnPaint()
{
	RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, 0);
	if (gIsPainting) return;
	gIsPainting = true;

	CPaintDC dc(this);
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		
		GetClientRect(&mRect);
		mCurrentWidth = mPacker.GetBoundingWidth();
		mCurrentHeight = mPacker.GetBoundingHeight();

		//draw image to dialog
		CDC memDC;
		CBitmap memBitmap;
		memDC.CreateCompatibleDC(&dc);
		memBitmap.CreateCompatibleBitmap(&dc, mRect.Width(), mRect.Height());
		CBitmap* pOldBitmap = memDC.SelectObject(&memBitmap); //allow draw from cdc to bitmap
		memDC.FillSolidRect(0, 0, mRect.Width(), mRect.Height(), RGB(255, 255, 255));
		Graphics graphics(memDC.GetSafeHdc());
		graphics.Clear(Color(255, 255, 255));

		mPositions = mPacker.GetImages();
		for (int i = 0; i < mPositions.size(); ++i)
		{
			Image image(mPositions[i].GetFilePath());

			if (mCurrentWidth <= mWidthDraw && mCurrentHeight <= mHeightDraw) {
				mOffsetX = mOffsetY = 0;
			}
			int offsetX = mPositions[i].GetX() - mOffsetX;
			int offsetY = mPositions[i].GetY() - mOffsetY;
			int originalWidth = mPositions[i].GetWidth();
			int originalHeight = mPositions[i].GetHeight();

			graphics.DrawImage(&image, offsetX, offsetY, originalWidth, originalHeight);

			//CString fileName = mPositions[i].GetFilePath().Mid(mPositions[i].GetFilePath().ReverseFind('\\') + 1);
			CString fileName = mPositions[i].GetFilePath();
			if (fileName == gSelectedImage) {
				Pen pen(Color(255, 0, 0));
				pen.SetWidth(2);
				graphics.DrawRectangle(&pen, offsetX + 1, offsetY + 1, originalWidth - 2, originalHeight - 2);
			}
		}
		if (!mPositions.empty()){
			LayoutInit(gIsLayoutInit);
			dc.BitBlt(mDrawX, mDrawY, mWidthDraw, mHeightDraw, &memDC, 0, 0, SRCCOPY);
		}
		memDC.SelectObject(pOldBitmap);

		//update scrollbar
		UpdatedScroll(mCurrentWidth, mCurrentHeight);
		
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CDialogImageDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


std::vector<std::shared_ptr<ThisImage>> pImages;
void CDialogImageDlg::OnFolderOpen()
{
	CFolderPickerDialog folderDlg(NULL, BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE, this);

	if (folderDlg.DoModal() == IDOK) {
		pImages.clear();
		CString selectedFolder = folderDlg.GetPathName();

		FindImageFiles(selectedFolder);
		SortAndDisplayTree(selectedFolder);
		mPacker.Clear();
		ArrangeImage(mDrawX);

		gZoomFactor = 1.0f;
		gImageDraging = false;
		gIsPainting = false;
		gNewImage = true;
		
		Invalidate();


	}
}
void CDialogImageDlg::SortAndDisplayTree(CString selectedFolder)
{


	auto& treeList = pImages;
	mTreeView.DeleteAllItems();
	HTREEITEM hRoot = mTreeView.InsertItem(_T("Images List"));
	map<CString, HTREEITEM> folderMap;

	for (const auto& treeName : treeList) {
		CString filePath = treeName.get()->GetFilePath();


		int pos = filePath.ReverseFind('\\');
		if (pos != -1) {
			CString folderPath = filePath.Left(pos);
			int posLeft = folderPath.ReverseFind('\\');
			if (posLeft != -1) {
				CString folderName = folderPath.Mid(posLeft + 1);
				HTREEITEM hFolder = NULL;
				if (folderPath.CompareNoCase(selectedFolder) == 0) {
					CString fileName = filePath.Mid(pos + 1);
					hFolder = mTreeView.InsertItem(fileName, hRoot);
					itemDataMap[hFolder] = filePath;

				}
				else {

					auto it = folderMap.find(folderPath);
					if (it == folderMap.end()) {

						hFolder = mTreeView.InsertItem(folderName, hRoot);
						folderMap[folderPath] = hFolder;

					}
					else {
						hFolder = it->second;
					}
					CString fileName = filePath.Mid(pos + 1);
					HTREEITEM hItem = mTreeView.InsertItem(fileName, hFolder);
					itemDataMap[hItem] = filePath;
				}
			}
		}
	}

	mTreeView.Expand(hRoot, TVE_EXPAND);
	HTREEITEM hChild = mTreeView.GetChildItem(hRoot);
	while (hChild != NULL) {
		mTreeView.Expand(hChild, TVE_EXPAND);
		hChild = mTreeView.GetNextItem(hChild, TVGN_NEXT);
	}


}

void CDialogImageDlg::ArrangeImage(int drawX)
{
	GetClientRect(&mRect);
	int initialWidth = mRect.Width() - drawX - X_PADDING;

	for (auto& img : pImages) {
		CString path = img->GetFilePath();
		int width = img->GetWidth();
		int height = img->GetHeight();
		mPacker.AddImage(ThisImage(path, width, height));

	}
	mPacker.Pack(initialWidth);
	
}




void CDialogImageDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	if (pScrollBar == &mHorizontalControl)
	{
		int scrollDelta = 0;

		switch (nSBCode)
		{
		case SB_LINELEFT:
			scrollDelta = -3;
			break;
		case SB_LINERIGHT:
			scrollDelta = 3;
			break;
		case SB_THUMBTRACK:
			scrollDelta = static_cast<int>(std::round(nPos - mCurrentPosScrollWidth));
			break;
		}

		int maxScroll = mHorizontalControl.GetScrollLimit();
		if (mCurrentPosScrollWidth + scrollDelta < 0)
			scrollDelta = static_cast<int>(std::round(-mCurrentPosScrollWidth));
		else if (mCurrentPosScrollWidth + scrollDelta > maxScroll)
			scrollDelta = static_cast<int>(std::round(maxScroll - mCurrentPosScrollWidth));

		mOffsetX += scrollDelta;
		mCurrentPosScrollWidth += scrollDelta;
		mOldPosScrollWidth = mCurrentPosScrollWidth;
		mHorizontalControl.SetScrollPos(static_cast<int>(std::round(mCurrentPosScrollWidth)));

		gIsPainting = false;
		InvalidateRect(NULL, FALSE);

	}

	CDialogEx::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CDialogImageDlg::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
	if (pScrollBar == &mVerticalControl)
	{

		int scrollDelta = 0;

		switch (nSBCode)
		{
		case SB_LINEUP:
			scrollDelta = -3;
			break;
		case SB_LINEDOWN:
			scrollDelta = 3;
			break;
		case SB_THUMBTRACK:
			scrollDelta = static_cast<int>(std::round(nPos - mCurrentPosScrollHeight));
			break;
		}

		int maxScroll = mVerticalControl.GetScrollLimit();
		if (mCurrentPosScrollHeight + scrollDelta < 0)
			scrollDelta = static_cast<int>(std::round(-mCurrentPosScrollHeight));
		else if (mCurrentPosScrollHeight + scrollDelta > maxScroll)
			scrollDelta = static_cast<int>(std::round(maxScroll - mCurrentPosScrollHeight));

		mOffsetY += scrollDelta;
		mCurrentPosScrollHeight += scrollDelta;
		mOldPosScrollHeight = mCurrentPosScrollHeight;
		mVerticalControl.SetScrollPos(static_cast<int>(std::round(mCurrentPosScrollHeight)));

		gIsPainting = false;
		InvalidateRect(NULL, FALSE);

	}

	CDialogEx::OnVScroll(nSBCode, nPos, pScrollBar);
}


void CDialogImageDlg::OnTvnSelchangedTree1(NMHDR* pNMHDR, LRESULT* pResult)
{
	LPNMTREEVIEW pNMTreeView = reinterpret_cast<LPNMTREEVIEW>(pNMHDR);
	HTREEITEM hItem = pNMTreeView->itemNew.hItem;
	gSelectedImage = mTreeView.GetItemText(hItem);

	auto it = itemDataMap.find(hItem);
	if (it != itemDataMap.end()) {
		CString fullPath = it->second;
		gSelectedImage = fullPath;

	}
	gIsPainting = false;
	gTreeClicked = true;
	InvalidateRect(NULL, FALSE);
	*pResult = 0;
}

void FindImageFiles(const CString& rDirPath)
{
	CFileFind finder;
	CString searchPath = rDirPath + L"\\*.*";
	BOOL bIsFinding = finder.FindFile(searchPath);

	CStringArray validExtensions;
	validExtensions.Add(L".bmp");
	validExtensions.Add(L".jpg");
	validExtensions.Add(L".jpeg");
	validExtensions.Add(L".png");

	while (bIsFinding) {
		bIsFinding = finder.FindNextFile();

		if (finder.IsDirectory()) {
			CString folderPath = finder.GetFilePath();

			if (finder.GetFileName() != _T(".") && finder.GetFileName() != _T("..")) {
				FindImageFiles(folderPath);
			}
		}
		else {
			CString filePath = finder.GetFilePath();
			int dotPos = filePath.ReverseFind('.');
			if (dotPos != -1) {
				CString fileExtensions = filePath.Mid(dotPos);

				bool isValid = false;
				for (int i = 0; i < validExtensions.GetSize(); ++i) {
					if (fileExtensions.CompareNoCase(validExtensions[i]) == 0) {
						isValid = true;
						break;
					}
				}
				if (isValid) {

					Image image(filePath);
					int width = image.GetWidth();
					int height = image.GetHeight();

					std::shared_ptr<ThisImage> pEachImage = std::make_shared<ThisImage>(filePath, width, height);
					pImages.push_back(pEachImage);
				}
			}

		}
	}
}


void CDialogImageDlg::OnLButtonDown(UINT nFlags, CPoint point)
{

		for (size_t i =0; i< mPositions.size(); ++i)
		{
			if (IsPointInImage(mPositions[i], point, mDrawX, mDrawY))
			{
				pDraggedImage = &mPositions[i];
				mDragStartPoint = point;
				mDragStartPoint.x = pDraggedImage->GetX();
				mDragStartPoint.y = pDraggedImage->GetY();

				gImageDraging = true;
				mPacker.ChooseImage(pDraggedImage);
				SetCapture();
				
				break;
			}
	}

	CDialogEx::OnLButtonDown(nFlags, point);
}



void CDialogImageDlg::OnMouseMove(UINT nFlags, CPoint point)
{
	if (gImageDraging == true && pDraggedImage != nullptr)
	{
		
		mPacker.DraggingProcess(point, mDrawX, mDrawY);
		gIsPainting = false;
		

	}
	
	InvalidateRect(NULL, FALSE);
	CDialogEx::OnMouseMove(nFlags, point);
}

void CDialogImageDlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	if (gImageDraging == true && pDraggedImage != nullptr)
	{
		ReleaseCapture();
		gIsPainting = false;
		gImageDraging = false;
		mPacker.UpdatePositions(mDragStartPoint);	
		pDraggedImage = nullptr;
		
		
	}
	
	InvalidateRect(NULL, FALSE);
	CDialogEx::OnLButtonUp(nFlags, point);
}

void CDialogImageDlg::OnZoomIn()
{
	GetClientRect(&mRect);
	int widthLimit = mRect.Width() - mDrawX - EXTENSION;
	int heightLimit = mRect.Height() - mDrawY - EXTENSION;
	gZoomFactor = 1.2f;
	mOldLenScrollWidth = (mCurrentWidth - widthLimit) <= 0 ? 1 : (mCurrentWidth - widthLimit);
	mOldPosScrollWidth = mOldLenScrollWidth / 2;
	mOldLenScrollHeight = mCurrentHeight - heightLimit;
	mOldPosScrollHeight = mOldLenScrollHeight / 2;
	gIsZoomInWidth = gIsZoomInHeight = true;
	gIsPainting = false;
	mPacker.ZoomAndRedraw(gZoomFactor);
	InvalidateRect(NULL, FALSE);
}

void CDialogImageDlg::OnZoomOut()
{
	GetClientRect(&mRect);
	int widthLimit = mRect.Width() - mDrawX - EXTENSION;
	int heightLimit = mRect.Height() - mDrawY - EXTENSION;
	gZoomFactor = 0.8f;
	mOldLenScrollWidth = (mCurrentWidth - widthLimit) <= 0 ? 1 : (mCurrentWidth - widthLimit);
	mOldPosScrollWidth = mOldLenScrollWidth / 2;
	mOldLenScrollHeight = mCurrentHeight - heightLimit;
	mOldPosScrollHeight = mOldLenScrollHeight / 2;
	gIsZoomOut = true;
	gIsPainting = false;
	mPacker.ZoomAndRedraw(gZoomFactor);
	InvalidateRect(NULL, FALSE);
}

void CDialogImageDlg::UpdatedScroll(int& rNewWidth, int& rNewHeight)
{
	
	GetClientRect(&mRect);
	int widthLimit = mRect.Width() - mDrawX - EXTENSION;
	int heightLimit = mRect.Height() - mDrawY - EXTENSION;
	if (rNewWidth > widthLimit)  //beyond dialog
	{
		mCurrentLenScrollWidth = rNewWidth - widthLimit;
		mHorizontalControl.ShowWindow(SW_SHOW);
		mHorizontalControl.SetScrollRange(0, static_cast<int>(std::round(mCurrentLenScrollWidth)));

		if (gIsZoomInWidth || gIsZoomOut) {
			mCurrentPosScrollWidth = mOldPosScrollWidth * (mCurrentLenScrollWidth / mOldLenScrollWidth);
			mHorizontalControl.SetScrollPos(static_cast<int>(std::round(mCurrentPosScrollWidth)));
			gIsZoomInWidth = false;
		}
	}
	else                         //inside dialog
	{

		mHorizontalControl.ShowWindow(SW_HIDE);
		mHorizontalControl.SetScrollRange(0, 0);
		gIsZoomInWidth = false;

	}

	if (rNewHeight > heightLimit)
	{
		mCurrentLenScrollHeight = rNewHeight - heightLimit;
		mVerticalControl.ShowWindow(SW_SHOW);
		mVerticalControl.SetScrollRange(0, static_cast<int>(std::round(mCurrentLenScrollHeight)));
		if (gIsZoomInHeight || gIsZoomOut) {
			mCurrentPosScrollHeight = mOldPosScrollHeight * (mCurrentLenScrollHeight / mOldLenScrollHeight);
			mVerticalControl.SetScrollPos(static_cast<int>(std::round(mCurrentPosScrollHeight)));
			gIsZoomInHeight = gIsZoomOut = false;
		}
	}
	else
	{
		mVerticalControl.ShowWindow(SW_HIDE);
		mVerticalControl.SetScrollRange(0, 0);
		gIsZoomInHeight = gIsZoomOut = false;
	}

}


bool IsPointInImage(const ThisImage& rImage, const CPoint& rPoint, int xPadding, int yPadding)
{

	return (rPoint.x >= rImage.GetX() + xPadding && rPoint.x <= rImage.GetX() + rImage.GetWidth() + xPadding &&
		rPoint.y >= rImage.GetY() + yPadding && rPoint.y <= rImage.GetY() + rImage.GetHeight() + yPadding);
}



void CDialogImageDlg::OnSizing(UINT fwSide, LPRECT pRect)
{
	CDialogEx::OnSizing(fwSide, pRect);


	// TODO: Add your message handler code here
	int minWidth = 680; 
	int minHeight = 480; 

	if (pRect->right - pRect->left < minWidth) {
		pRect->right = pRect->left + minWidth;  
	}

	if (pRect->bottom - pRect->top < minHeight) {
		pRect->bottom = pRect->top + minHeight;  
	}
	gIsPainting = false;
	InvalidateRect(NULL, FALSE);
}


void CDialogImageDlg::OnSize(UINT nType, int cx, int cy)
{
	CDialogEx::OnSize(nType, cx, cy);

	// TODO: Add your message handler code here
	mRect.SetRect(0, 0, cx, cy);
	gIsPainting = false;
	InvalidateRect(NULL, FALSE);
}


void CDialogImageDlg::OnMove(int x, int y)
{
	CDialogEx::OnMove(x, y);

	// TODO: Add your message handler code here
	gIsPainting = false;
	InvalidateRect(NULL, FALSE);
}
