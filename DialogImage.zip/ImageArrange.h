#ifndef IMAGEARRANGE_H
#define IMAGEARRANGE_H

#include "Image.h"
#include <vector>
#include <algorithm>

using namespace std;

constexpr int EXTENSION = 50;

extern bool gImageDraging;

class ImageArrange
{
private:
    vector<ThisImage> mImagePack;
    int mBoundingWidth;
    int mBoundingHeight;
    int mPackedWidth, mPackedHeight = 0;
    vector<vector<bool>>mGrid;
    //Algorithm
    void SortImagesByHeight();
    void ArrangeImages();
    void ExpandGrid(int newWidth, int newHeight);

public:
    //Constructor
    ImageArrange();
    ImageArrange(int boundingWidth);
    //Manipulate with images
    void AddImage(const ThisImage& rImage);
    void UpdatePositions(CPoint startPoint);
    void DraggingProcess(CPoint point, int toolbarX, int toolbarY);
    void ChooseImage(ThisImage* pDraggedImage);
    void ZoomAndRedraw(double& rZoom);
    void Pack(int initialWidth);
    void Clear();
    //Getter
    int GetBoundingWidth() const;
    int GetBoundingHeight() const;
    int GetBoundingArea() const;
    const vector<ThisImage>& GetImages() const;


};

#endif // ImageArrange_H