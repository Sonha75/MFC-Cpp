#ifndef IMAGE_H
#define IMAGE_H

#pragma once
#include <vector>
#include <algorithm>


class ThisImage {
private:
    CString mImagePath;
    int mWidth;
    int mHeight;
    int mX;
    int mY;
    bool mWasPacked = false;
public:
    ThisImage(const CString& rPath, int w, int h);

    // Getter
    int GetWidth()const;
    int GetHeight() const;
    int GetX() const;
    int GetY() const;
    int GetArea() const;
    const CString& GetFilePath() const { return mImagePath; }

    // Setter
    void SetPosition(int x, int y);
    void SetNewSize(int newWidth, int newHeight);
    bool IsPacked() const;
    void SetPacked(bool isPacked);
};


#endif // IMAGE>.H