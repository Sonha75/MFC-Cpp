
#include "pch.h"
#include "ImageArrange.h"



//Constructor
ImageArrange::ImageArrange() : mBoundingWidth(0), mBoundingHeight(0), mPackedWidth(0), mPackedHeight(0) {
    mGrid.resize(1, vector<bool>(mBoundingWidth, false));
}

ImageArrange::ImageArrange(int boundingWidth) : mBoundingHeight(0), mPackedWidth(0), mBoundingWidth(boundingWidth), mGrid(1, vector<bool>(boundingWidth, false)) {}

//Getter
int ImageArrange::GetBoundingWidth() const {
    return mBoundingWidth;
}

int ImageArrange::GetBoundingHeight() const {
    return mBoundingHeight;
}

int ImageArrange::GetBoundingArea() const {
    return mBoundingWidth * mBoundingHeight;
}

const std::vector<ThisImage>& ImageArrange::GetImages() const {
    return mImagePack;
}

//Manipulate with images
void ImageArrange::AddImage(const ThisImage& rImage) {
    mImagePack.push_back(rImage);
}

void ImageArrange::Clear() {
    mImagePack.clear();
    mBoundingWidth = 0;
    mBoundingHeight = 0;
}

void ImageArrange::ZoomAndRedraw(double& rZoomFactor) {
    mBoundingWidth = static_cast<int>(mBoundingWidth * rZoomFactor);
    mBoundingHeight = static_cast<int>(mBoundingHeight * rZoomFactor);

    for (auto& image : mImagePack) {

        int newX = static_cast<int>(image.GetX() * rZoomFactor);
        int newY = static_cast<int>(image.GetY() * rZoomFactor);


        int newWidth = static_cast<int>(image.GetWidth() * rZoomFactor);
        int newHeight = static_cast<int>(image.GetHeight() * rZoomFactor);


        image.SetPosition(newX, newY);
        image.SetNewSize(newWidth, newHeight);
    }
}

void ImageArrange::Pack(int initialWidth) {
    mBoundingWidth = initialWidth;
    SortImagesByHeight();
    ArrangeImages();

}


void ImageArrange::DraggingProcess(CPoint point, int toolbarX, int toolbarY)
{
    int centerX = point.x  - toolbarX;
    int  centerY = point.y  - toolbarY;
       
    mImagePack[mImagePack.size() - 1].SetPosition(centerX - mImagePack[mImagePack.size() - 1].GetWidth() / 2, centerY - mImagePack[mImagePack.size() - 1].GetHeight() / 2);
        
 

}

void ImageArrange::ChooseImage(ThisImage* pDraggedImage)
{
    
    
    for (size_t i = 0; i < mImagePack.size(); ++i) {

        if (mImagePack[i].GetWidth() == pDraggedImage->GetWidth() && mImagePack[i].GetHeight() == pDraggedImage->GetHeight()) {

            ThisImage tempImage = mImagePack[i];
            for (size_t j = i; j < mImagePack.size() - 1; ++j) {
                mImagePack[j] = mImagePack[j + 1];
            }
            mImagePack[mImagePack.size() - 1] = tempImage;
            break;
        }
    }
    
}

void ImageArrange::UpdatePositions(CPoint startPoint)
{
    int centerX = mImagePack[mImagePack.size() - 1].GetX() + mImagePack[mImagePack.size() - 1].GetWidth() / 2;
    int centerY = mImagePack[mImagePack.size() - 1].GetY() + mImagePack[mImagePack.size() - 1].GetHeight() / 2;
    
    for (size_t i = 0; i < mImagePack.size()-1; ++i) {
        if (centerX >= mImagePack[i].GetX() && centerX <= mImagePack[i].GetX() + mImagePack[i].GetWidth() &&
            centerY >= mImagePack[i].GetY() && centerY <= mImagePack[i].GetY() + mImagePack[i].GetHeight()) {
            mImagePack[mImagePack.size()-1].SetPosition(mImagePack[i].GetX(), mImagePack[i].GetY());
            mImagePack[i].SetPosition(startPoint.x, startPoint.y);
        }
    }
    int minX = mImagePack[0].GetX();
    int minY = mImagePack[0].GetY();
    int maxX = mImagePack[0].GetX() + mImagePack[0].GetWidth();
    int maxY = mImagePack[0].GetY() + mImagePack[0].GetHeight();

    for (size_t i = 1; i < mImagePack.size(); ++i) {
        int imageX = mImagePack[i].GetX();
        int imageY = mImagePack[i].GetY();
        int imageWidth = mImagePack[i].GetWidth();
        int imageHeight = mImagePack[i].GetHeight();

        if (imageX < minX) minX = imageX;
        if (imageY < minY) minY = imageY;
        if (imageX + imageWidth > maxX) maxX = imageX + imageWidth;
        if (imageY + imageHeight > maxY) maxY = imageY + imageHeight;
    }
    mBoundingWidth = maxX - minX;
    mBoundingHeight = maxY - minY;
}

//Algorithm
void ImageArrange::SortImagesByHeight() {
    std::sort(mImagePack.begin(), mImagePack.end(), [](const ThisImage& a, const ThisImage& b) {
        if (a.GetHeight() != b.GetHeight()) {
            return a.GetHeight() > b.GetHeight();
        }
        else {
            return a.GetArea() > b.GetArea();
        }
        });
}

void ImageArrange::ExpandGrid(int newWidth, int newHeight) {
    int currentHeight = mGrid.size();

    if (newWidth > mBoundingWidth) {
        newWidth = mBoundingWidth;
    }
    if (newHeight > currentHeight) {
        mGrid.resize(newHeight, vector<bool>(mBoundingWidth, false));
    }
}

void ImageArrange::ArrangeImages() {
    mPackedHeight = 0;
    mGrid = vector<vector<bool>>(1, vector<bool>(mBoundingWidth, false));
    for (auto& image : mImagePack) {
        bool isPlaced = false;
        for (int y = 0;y <= mPackedHeight && !isPlaced;++y) {
            for (int x = 0;x + image.GetWidth() <= mBoundingWidth && !isPlaced;++x) {
                if (y + image.GetHeight() > mPackedHeight) {
                    ExpandGrid(mBoundingWidth, y + image.GetHeight());
                }
                bool isFit = true;
                for (int i = 0; i < image.GetHeight() && isFit;++i) {
                    for (int j = 0;j < image.GetWidth() && isFit; ++j) {
                        if (mGrid[y + i][x + j]) {
                            isFit = false;
                            break;
                        }
                    }
                }
                if (isFit) {
                    image.SetPosition(x, y);
                    for (int i = 0;i < image.GetHeight();++i) {
                        for (int j = 0;j < image.GetWidth();++j) {
                            mGrid[y + i][x + j] = true;
                        }
                    }
                    image.SetPacked(true);
                    isPlaced = true;
                }
            }
        }
        mPackedWidth = mBoundingWidth;
        mPackedHeight = max(mPackedHeight, image.GetY() + image.GetHeight());

    }
    mBoundingHeight = mPackedHeight;
}