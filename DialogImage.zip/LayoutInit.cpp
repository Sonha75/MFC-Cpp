
#include "pch.h"
#include "LayoutInit.h"


void CDialogImageDlg::LayoutInit(bool isLayoutInit) {
	GetClientRect(&mRect);

	int widthToolbar = mRect.Width(); 
	//mWndToolBar.GetItemRect(0, &temp);
	int heightToolbar = 38;


	int widthTreeArea = static_cast<int>(mRect.Width() * static_cast < double>(1) / 5);
	int heightTreeArea = mRect.Height() - heightToolbar - Y_PADDING;

	int widthInfoArea = static_cast<int>(mRect.Width() * static_cast<double>(1) / 5);
	int heightInfoArea = heightTreeArea;

	mDrawX = widthTreeArea;
	mDrawY = heightToolbar;
	mWidthDraw = mRect.Width() - widthTreeArea - widthInfoArea - X_PADDING;
	mHeightDraw = heightTreeArea;

	if (!isLayoutInit) {
		ToolbarInit(0, 0, widthToolbar, heightToolbar);
		TreeControlInit(0, heightToolbar, widthTreeArea, heightTreeArea);
		InfoControlInit(mRect.Width() - widthInfoArea - mRect.Width()* static_cast <double>(1) / 10, heightToolbar, widthInfoArea, heightInfoArea);
		
	}
	else {
		
		mTreeView.MoveWindow(0, heightToolbar, widthTreeArea, heightTreeArea);
		mInfoControl.MoveWindow(mRect.Width() - widthInfoArea - X_PADDING, heightToolbar, widthInfoArea, heightInfoArea);
		mInfoControl.ShowWindow(SW_SHOW);
		mTreeView.ShowWindow(SW_SHOW);
	}

}


void CDialogImageDlg::ToolbarInit(int x, int y, int width, int height) {
	mWndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP | CBRS_NOALIGN);
	mWndToolBar.LoadToolBar(IDR_TOOLBAR1);
	mWndToolBar.SetBarStyle(mWndToolBar.GetBarStyle() | CBRS_TOP | CBRS_GRIPPER);
	RepositionBars(AFX_IDW_CONTROLBAR_FIRST, AFX_IDW_CONTROLBAR_LAST, 0);
}

void CDialogImageDlg::InfoControlInit(int x, int y, int width, int height) {
	mInfoControl.SubclassDlgItem(IDC_INFO_IMAGE, this);
	mInfoControl.MoveWindow(x, y, width,height);
	CString strInfo;
	int a = 10;
	strInfo.Format(L"Hello, I am Son\nThis is static %d", a);
	mInfoControl.SetWindowTextW(strInfo);
	mInfoControl.ModifyStyle(0, SS_BLACKFRAME);
	mInfoControl.ShowWindow(SW_HIDE);
}

void CDialogImageDlg::TreeControlInit(int x, int y, int width, int height) {
	mTreeView.SubclassDlgItem(IDC_TREE1, this);
	mTreeView.MoveWindow(x, y, width, height);
	mTreeView.ShowWindow(SW_HIDE);
}




