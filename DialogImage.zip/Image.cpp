#include "pch.h"
#include "Image.h"

// Constructor
ThisImage::ThisImage(const CString& rPath, int w, int h) : mImagePath(rPath), mWidth(w), mHeight(h), mX(0), mY(0) {}


// Getter
int ThisImage::GetWidth() const {
    return mWidth;
}

int ThisImage::GetHeight() const {
    return mHeight;
}

int ThisImage::GetX() const {
    return mX;
}

int ThisImage::GetY() const {
    return mY;
}

int ThisImage::GetArea() const {
    return mWidth * mHeight;
}


// Setter
void ThisImage::SetPosition(int newX, int newY) {
    mX = newX;
    mY = newY;
}

void ThisImage::SetNewSize(int newWidth, int newHeight) {
    mWidth = newWidth;
    mHeight = newHeight;
}

bool ThisImage::IsPacked() const {
    return mWasPacked;
}

void ThisImage::SetPacked(bool isPacked) {
    mWasPacked = isPacked;
}

