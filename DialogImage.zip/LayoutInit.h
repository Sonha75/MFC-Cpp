
#pragma once

#include "DialogImage.h"
#include "DialogImageDlg.h"



//#define heightToolbar 38
#define X_PADDING 30
#define Y_PADDING 80


